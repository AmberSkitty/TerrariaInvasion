using Terraria.ModLoader;

namespace Invasion
{
	public class Invasion : Mod
	{
	}
}