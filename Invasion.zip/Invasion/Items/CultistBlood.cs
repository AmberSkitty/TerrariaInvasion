﻿using Terraria;
using Terraria.ModLoader;
using Terraria.ID;

namespace Invasion.Items
{
    public class CultistBlood : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Cultist Blood");
            Tooltip.SetDefault("The blood of lunatic sacrifices.");
        }

        public override void SetDefaults()
        {
            item.width = 14;
            item.height = 14;
            item.maxStack = 99;
            item.value = Item.sellPrice(0, 0, 1, 20);
            item.rare = 1;
        }
    }
}
