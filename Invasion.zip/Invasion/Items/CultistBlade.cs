using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using static Terraria.ModLoader.ModContent;

namespace Invasion.Items
{
	public class CultistBlade : ModItem
	{
		public override void SetStaticDefaults() 
		{
			// DisplayName.SetDefault("CultistBlade"); // By default, capitalization in classnames will add spaces to the display name. You can customize the display name here by uncommenting this line.
			Tooltip.SetDefault("A blade infused with the blood of sacrifices, forged by devoted cultists.");
		}

		public override void SetDefaults() 
		{
			item.damage = 108;
			item.melee = true;
			item.width = 40;
			item.height = 40;
			item.useTime = 20;
			item.useAnimation = 20;
			item.useStyle = 1;
			item.knockBack = 6;
			item.value = Item.buyPrice(0, 2, 1, 30);
			item.rare = 3;
			item.UseSound = SoundID.Item1;
			item.autoReuse = true;
		}

		public override void AddRecipes() 
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemType<CultistBlood>(), 20);
			recipe.AddIngredient(ItemID.FragmentNebula, 40);
			recipe.AddIngredient(ItemID.FragmentSolar, 40);
			recipe.AddIngredient(ItemID.FragmentVortex, 40);
			recipe.AddIngredient(ItemID.FragmentStardust, 40);
			recipe.AddTile(TileID.MythrilAnvil);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
	}
}